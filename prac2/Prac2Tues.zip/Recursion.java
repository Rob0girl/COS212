
public class Recursion {
    
        public int recursion(int num)
        {
            /*put your code here*/
            return 0;
            
        }
 
}

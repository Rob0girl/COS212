
import java.util.ArrayList;
import java.util.Collections;

public class WordJumble {
    
    public ArrayList<String> permutations = new ArrayList<String>();
    
    public void solve(String word,int index)
    {
        /*put your code here*/
    }
    
    public void addToList(String add)
    {
        permutations.add(add);
    }
    
    public void printList()
    {
	Collections.sort(permutations);
        System.out.println(permutations);
    }
    
    public void reset()
    {
        permutations = new ArrayList<String>();
    }
    
}
